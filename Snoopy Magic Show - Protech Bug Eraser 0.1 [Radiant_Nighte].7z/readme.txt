Snoopy Magic Show - Protech Bug Eraser 0.1  [Radiant Nighte]



Fixes:  [Japan, Usa, Japan dx 1.0 - marc_max]
+ Adds missing bottom star corners during ending
+ Adds missing bottom-right corner pixel of border window

# Moves victory pose ypos during versus win when other player dies

- Removes screen flicker during ending mid-scene
- Removes sprite garbage during ending mid-scene
- Removes 2 frames of micro-stutter during gameplay



Fixes:  [Japan dx 1.0 - marc_max]
+ Adds missing pixel of flag during ending
+ Adds missing pixel of sky during story cutscene
+ Adds missing star animation during ending

- Removes 1 frame of screen flicker during legal screen
- Removes tile garbage and 1 frame of screen flicker during 2P versus menu
