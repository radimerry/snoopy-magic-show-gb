Snoopy Magic Show - Protech Hacks Catalog 0.1  [Radiant Nighte]



Change Player 0.1:  [Japan, USA, Japan DX 1.0 - marc_max]
- Press SELECT at stage menu to switch players (Snoopy or Spike)
  ~ notice: story and cutscenes remain unchanged





Tested patching order:
- Japan + Protech
- USA + Protech

- Japan + DX 1.0 + Protech





Source: MIT License
https://github.com/radimerry/snoopy-magic-show-gb/tree/hacks-catalog
