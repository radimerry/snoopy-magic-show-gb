Snoopy Magic Show - Protech Bug Eraser 0.3  [Radiant Nighte]



Fixes:  [Japan, USA, Japan DX 1.0 - marc_max]
+ Adds missing bottom star corners during ending
+ Adds missing bottom-right corner pixel of border window

# Move victory pose ypos during versus win when other player dies
# Move Snoopy and Spike starting position during title screen to avoid pop-in from right side
# Move pause sprite to be on top of other graphics

- Removes screen flicker during ending mid-scene
- Removes sprite garbage during ending mid-scene
- Removes 2 frames of micro-stutter during gameplay





Fixes:  [Japan DX 1.0 - marc_max]
+ Adds missing pixel of flag during ending
+ Adds missing pixel of sky during story cutscene
+ Adds missing star and text animation during ending

- Removes 1 frame of screen flicker during legal screen
- Removes tile garbage and 1 frame of screen flicker during 2P versus menu





Tested patching order:
- Japan + Protech
- USA + Protech

- Japan + DX 1.0 + Protech





Changelog:
- 0.3   https://github.com/radimerry/snoopy-magic-show-gb/compare/game-fixes-0.2..game-fixes-0.3
- 0.2   https://github.com/radimerry/snoopy-magic-show-gb/compare/game-fixes-0.1..game-fixes-0.2





Source: MIT License
https://github.com/radimerry/snoopy-magic-show-gb/tree/game-fixes
